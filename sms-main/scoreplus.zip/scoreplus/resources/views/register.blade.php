<!DOCTYPE html>
<html>
<head>
  <title>新規講師登録</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="/static/register.css">
</head>
<body>
  <div class="content2">
    <!-- <a onclick="history.back()" class="submit">戻る</a> -->
    <a href="/logout" class="submit">ログアウト</a>
  </div>
  <div class="container">
  <div class="headline">
    <h1>新規講師登録</h1>
  </div>
  <!-- <a onclick="history.back()" class="">戻る</a> -->
  
  <form action="/register" method="POST" name="register">
    <div class="mb-3">
      <label for="name" class="form-label">講師名</label>
      <input type="text" class="form-control" name="teacher_name" id="exampleInputName1" value="" required>
    </div>
    <div class="mb-3">
      <label for="name" class="form-label">フリガナ</label>
      <input type="text" class="form-control" name="name_sub" id="exampleInputName2" value="" required>
    </div>
    <div class="mb-3">
      <label for="id" class="form-label">ID</label>
      <input type="text" class="form-control" name="ID" id ="exampleInputId1" value="" required>
    </div>
    <div class="mb-3">
      <label for="gender" class="form-label">性別</label>
      <input type="radio" class="form-check-input" name="gender" id ="exampleInputGender1" value="男性" checked>男性
      <input type="radio" class="form-check-input" name="gender" id ="exampleInputGender2" value="女性">女性
    </div>
    <div class="mb-3">
      <label for="age" class="form-label">年齢</label>
      <input type="text" class="form-control" name="age" id ="exampleInputAge1" value="" required>
    </div>
    <div class="mb-3">
      <label for="password" class="form-label">パスワード</label>
      <input type="password" class="form-control" name="password" id ="exampleInputPassword1" value="" required>
    </div>
    <div class="mb-3">
      <label for="password" class="form-label">再パスワード</label>
      <input type="password" class="form-control" name="password2" id ="exampleInputPassword2" value="" required>
    </div>
    <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
    <a href="javascript:register.submit()" class="bn3637 bn36">登録</a>
  </form>

  <a href="home" class="homeicon">
    <img src="../static/home_img/home.png" alt="home">
  </a>
</div>
</body>
</html>