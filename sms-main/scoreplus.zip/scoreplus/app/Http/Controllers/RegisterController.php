<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;
use Validator;
use App\User;

class RegisterController extends Controller
{

    public function get(Request $request)
    {
        return view("register");
    }

    public function post(Request $request)
    {
        $params = ["message" => "登録が完了しました"];
        return view("register", $params);
    }
}